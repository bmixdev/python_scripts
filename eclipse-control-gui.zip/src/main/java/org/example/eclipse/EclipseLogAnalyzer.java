package org.example.eclipse;

import java.io.*;

public class EclipseLogAnalyzer {
    public static boolean analyzeLog(File logFile) {
        if (!logFile.exists()) return true;

        boolean ok = true;
        try (BufferedReader r = new BufferedReader(new FileReader(logFile))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.contains("!ENTRY") && line.toLowerCase().contains("error")) {
                    System.err.println("Ошибка в логе: " + line);
                    ok = false;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ok;
    }
}