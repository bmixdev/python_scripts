package org.example.eclipse;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

public class EclipseLaunchRunner {

    public static void runLaunch(String launchFileName) throws Exception {
        String eclipseHome = new File(EclipseProcessInfo.getEclipseExePath()).getParent();
        File launcherJar = findLauncherJar(new File(eclipseHome, "plugins"));

        if (launcherJar == null) {
            throw new FileNotFoundException("Не найден org.eclipse.equinox.launcher*.jar");
        }

        URLClassLoader loader = new URLClassLoader(
            new URL[]{launcherJar.toURI().toURL()},
            Thread.currentThread().getContextClassLoader()
        );

        Class<?> mainClass = loader.loadClass("org.eclipse.equinox.launcher.Main");

        System.out.println("🔧 Запуск конфигурации: " + launchFileName);

        String[] args = {
            "-application", "org.eclipse.ui.ide.workbench",
            "-data", EclipseProcessInfo.getWorkspacePath(),
            "-launch", launchFileName
        };

        Method mainMethod = mainClass.getMethod("main", String[].class);
        mainMethod.invoke(null, (Object) args);
    }

    private static File findLauncherJar(File pluginsDir) {
        File[] files = pluginsDir.listFiles((dir, name) -> name.matches("org\.eclipse\.equinox\.launcher_.*\.jar"));
        return files != null && files.length > 0 ? files[0] : null;
    }
}