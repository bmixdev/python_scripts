package org.example.eclipse;

import java.io.*;
import java.util.*;

public class EclipseProjectBuilder {

    public static void main(String[] args) throws Exception {
        String workspace = EclipseProcessInfo.getWorkspacePath();
        String logPath = EclipseProcessInfo.getLogPath();

        List<String> projects = Arrays.asList(EclipseProcessInfo.getProjectList());
        String selectedProject = askUserToChoose(projects);

        if (selectedProject == null) {
            System.out.println("Проект не выбран.");
            return;
        }

        if (!User32Bindings.activateWindow("Eclipse")) {
            System.err.println("Окно Eclipse не найдено.");
            return;
        }

        Thread.sleep(1000);
        System.out.println("Clean + Build All → " + selectedProject);

        User32Bindings.sendAltKeySequence('P', 'C');
        Thread.sleep(1500);
        User32Bindings.typeText(selectedProject);
        User32Bindings.sendKey(User32Bindings.VK_ENTER);

        Thread.sleep(4000);
        User32Bindings.sendAltKeySequence('P', 'B');
        Thread.sleep(5000);

        boolean ok = EclipseLogAnalyzer.analyzeLog(new File(logPath));
        System.out.println(ok ? "✅ Успешно" : "❌ Есть ошибки");
    }

    private static String askUserToChoose(List<String> options) throws IOException {
        System.out.println("Выберите проект:");
        for (int i = 0; i < options.size(); i++) {
            System.out.printf("%d) %s%n", i + 1, options.get(i));
        }
        System.out.print("Введите номер: ");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int choice = Integer.parseInt(reader.readLine().trim());
        return (choice >= 1 && choice <= options.size()) ? options.get(choice - 1) : null;
    }
}