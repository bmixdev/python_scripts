package org.example.eclipse;

import com.sun.jna.*;
import com.sun.jna.platform.win32.*;
import com.sun.jna.win32.W32APIOptions;

public class User32Bindings {

    public static final int VK_MENU = 0x12;
    public static final int VK_ENTER = 0x0D;

    public static boolean activateWindow(String windowTitle) {
        WinDef.HWND hwnd = User32.INSTANCE.FindWindow(null, windowTitle);
        if (hwnd == null) return false;
        User32.INSTANCE.ShowWindow(hwnd, WinUser.SW_RESTORE);
        return User32.INSTANCE.SetForegroundWindow(hwnd);
    }

    public static void sendAltKeySequence(char menu, char sub) throws InterruptedException {
        sendComboKey(VK_MENU, Character.toUpperCase(menu));
        Thread.sleep(200);
        sendKey(Character.toUpperCase(sub));
    }

    public static void sendComboKey(int modifier, int key) throws InterruptedException {
        sendKey(modifier, true);
        sendKey(key, true);
        sendKey(key, false);
        sendKey(modifier, false);
    }

    public static void sendKey(int key) throws InterruptedException {
        sendKey(key, true);
        sendKey(key, false);
    }

    public static void sendKey(int key, boolean down) throws InterruptedException {
        WinUser.INPUT input = new WinUser.INPUT();
        input.type = new WinDef.DWORD(WinUser.INPUT.INPUT_KEYBOARD);
        input.input.setType("ki");
        input.input.ki = new WinUser.KEYBDINPUT();
        input.input.ki.wVk = new WinDef.WORD(key);
        input.input.ki.dwFlags = down ? 0 : WinUser.KEYEVENTF_KEYUP;

        User32.INSTANCE.SendInput(new WinDef.DWORD(1), new WinUser.INPUT[]{input}, input.size());
        Thread.sleep(50);
    }

    public static void typeText(String text) throws InterruptedException {
        for (char c : text.toCharArray()) {
            int vk = Character.toUpperCase(c);
            sendKey(vk, true);
            sendKey(vk, false);
        }
    }

    public interface User32 extends StdCallLibrary {
        User32 INSTANCE = Native.load("user32", User32.class, W32APIOptions.DEFAULT_OPTIONS);
        WinDef.HWND FindWindow(String lpClassName, String lpWindowName);
        boolean ShowWindow(WinDef.HWND hWnd, int nCmdShow);
        boolean SetForegroundWindow(WinDef.HWND hWnd);
        int SendInput(WinDef.DWORD nInputs, WinUser.INPUT[] pInputs, int cbSize);
    }
}