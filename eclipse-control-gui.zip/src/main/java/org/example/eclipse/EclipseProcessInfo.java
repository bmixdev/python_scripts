package org.example.eclipse;

import java.io.*;
import java.util.Properties;

public class EclipseProcessInfo {
    private static final String CONFIG_PROPERTY = "config";
    private static Properties props = new Properties();

    static {
        String configPath = System.getProperty(CONFIG_PROPERTY);
        if (configPath == null) {
            throw new IllegalStateException("Передайте путь к config.properties через -Dconfig=...");
        }
        try (InputStream input = new FileInputStream(configPath)) {
            props.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Ошибка загрузки config.properties: " + configPath, e);
        }
    }

    public static String getEclipseExePath() {
        return props.getProperty("eclipse.exe.path");
    }

    public static String getWorkspacePath() {
        return props.getProperty("workspace.path");
    }

    public static String getLogPath() {
        return getWorkspacePath() + "/.metadata/.log";
    }

    public static String[] getProjectList() {
        String raw = props.getProperty("projects");
        return raw != null ? raw.split(",") : new String[0];
    }
}