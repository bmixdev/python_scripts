#!/bin/bash

set -euo pipefail

RELEASE_BRANCH="$1"
FEATURE_BRANCHES_FILE="$2"
MODE="${3:-cherry-pick}"  # cherry-pick или merge

GITLAB_API_URL="${GITLAB_API_URL:-https://gitlab.com/api/v4}"
GITLAB_PROJECT_ID="${GITLAB_PROJECT_ID:?GITLAB_PROJECT_ID is required}"
GITLAB_TOKEN="${GITLAB_TOKEN:?GITLAB_TOKEN is required}"

LOG_FILE="merge_release.log"
> "$LOG_FILE"

timestamped_log() {
  local level="$1"
  local message="$2"
  local color="$3"
  local now
  now=$(date '+%Y-%m-%d %H:%M:%S')
  local formatted="[${level}] $now $message"
  if [[ -n "$color" ]]; then
    echo -e "${color}${formatted}[0m" | tee -a "$LOG_FILE"
  else
    echo "$formatted" | tee -a "$LOG_FILE"
  fi
}
log_info()  { timestamped_log "INFO"  "$1" "\033[1;34m"; }
log_warn()  { timestamped_log "WARN"  "$1" "\033[1;33m"; }
log_error() { timestamped_log "ERROR" "$1" "\033[1;31m"; }

git fetch origin

if ! git rev-parse --verify origin/"$RELEASE_BRANCH" &>/dev/null; then
  log_info "🆕 Релизная ветка $RELEASE_BRANCH не найдена. Создаю от master"
  git checkout -b "$RELEASE_BRANCH" origin/master
  git push origin "$RELEASE_BRANCH"
else
  git checkout "$RELEASE_BRANCH"
  git pull origin "$RELEASE_BRANCH"
fi

while read -r FEATURE_BRANCH; do
  [[ -z "$FEATURE_BRANCH" || "$FEATURE_BRANCH" == \#* ]] && continue

  log_info "🔍 Ищем все MR для ветки: $FEATURE_BRANCH"
  MRS=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
    "$GITLAB_API_URL/projects/$GITLAB_PROJECT_ID/merge_requests?state=merged&source_branch=$FEATURE_BRANCH")

  COUNT=$(echo "$MRS" | jq 'length')
  if [[ "$COUNT" -eq 0 ]]; then
    log_warn "⛔ Нет замерженных MR для ветки $FEATURE_BRANCH"
    continue
  fi

  for ((i = 0; i < COUNT; i++)); do
    MR_ID=$(echo "$MRS" | jq -r ".[$i].iid")
    log_info "✅ MR !${MR_ID} найден — получаем информацию"

    if [[ "$MODE" == "cherry-pick" ]]; then
      COMMITS=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
        "$GITLAB_API_URL/projects/$GITLAB_PROJECT_ID/merge_requests/$MR_ID/commits" | jq -r '.[].id')

      for commit in $COMMITS; do
        log_info "➡️ Cherry-pick коммита $commit"
        if ! git cherry-pick "$commit" -X theirs --no-edit; then
          log_warn "⚠️ Конфликт при cherry-pick $commit — откат"
          git cherry-pick --abort
          continue 3
        fi
      done

    elif [[ "$MODE" == "merge" ]]; then
      MERGE_COMMIT=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
        "$GITLAB_API_URL/projects/$GITLAB_PROJECT_ID/merge_requests/$MR_ID" | jq -r '.merge_commit_sha')

      if [[ "$MERGE_COMMIT" == "null" ]]; then
        log_warn "❌ merge_commit_sha отсутствует для MR !${MR_ID}"
        continue
      fi

      log_info "🔀 Merge коммита $MERGE_COMMIT"
      if ! git merge "$MERGE_COMMIT" --strategy=recursive -X theirs --no-edit; then
        log_warn "⚠️ Конфликт при merge $MERGE_COMMIT — откат"
        git merge --abort
        continue 2
      fi
    else
      log_error "❌ Неизвестный режим: $MODE"
      exit 1
    fi
  done

done < "$FEATURE_BRANCHES_FILE"

git push origin "$RELEASE_BRANCH"
log_info "✅ Релизная ветка обновлена: $RELEASE_BRANCH"
log_info "📘 Лог файл: $LOG_FILE"
