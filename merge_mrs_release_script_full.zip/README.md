# 🧩 merge_mrs_to_release.sh

Скрипт cherry-pick или merge коммитов всех MR по фичевым веткам в релизную ветку.

## ⚙️ Использование

```bash
export GITLAB_PROJECT_ID=123456
export GITLAB_TOKEN=glpat-xxxxx

./merge_mrs_to_release.sh release/1.2 features.txt cherry-pick
./merge_mrs_to_release.sh release/1.2 features.txt merge
```

## 💡 Сложные случаи

Если:
- Задача 1 изменила `ОбъектА` и была влита в `develop`
- Задача 2 тоже изменила `ОбъектА`, включая доработки из задачи 1
- В релизе нужна только задача 2

**Решение:**
- Использовать `cherry-pick` коммитов только из задачи 2
- Убедиться, что коммиты задачи 2 **не зависят** от изменений задачи 1 (либо cherry-pick задачу 1 тоже)
- В крайнем случае — вручную разрешить конфликты при cherry-pick

## 📄 Формат `features.txt`

```
feature/login
feature/cache
# feature/disabled
```

## 🔧 Требования

- git, bash, curl, jq
