# 🧩 merge_features_to_release.sh

Автоматический скрипт для вмерживания набора feature-веток в релизную ветку на основе `merge-base` с `develop`. Подходит для DevOps/CI/CD процессов, где релизы формируются из множества задач/MR.

## 🔧 Возможности

- ✅ Поддержка двух режимов: `cherry-pick` и `merge` (через аргумент `--mode`)
- ✅ Автоматически находит `merge-base` каждой фичи с `develop`
- ✅ Безопасно применяет изменения в `release` ветку
- ✅ Создаёт релизную ветку от `master`, если её ещё нет
- ✅ Поддержка источников:
  - вручную заданный список веток
  - автоматический сбор по label или milestone через GitLab API
- ✅ Ведение логов в файл `merge_release.log`
- ✅ Откат `git reset --hard` при ошибках
- ✅ Вывод `git log` изменений перед каждым merge/cherry-pick

## 🗂️ Структура

```bash
merge_features_to_release.sh <release-branch> [<develop-branch>] <features.txt> [mode]
```

### Аргументы

| Параметр             | Обязательный | Значение по умолчанию | Описание                                   |
|----------------------|--------------|------------------------|--------------------------------------------|
| `release-branch`     | ✅           | —                      | Целевая ветка для релиза (`release/1.2`)   |
| `develop-branch`     | ❌           | `develop`              | Базовая ветка для merge-base               |
| `features.txt`       | ✅           | —                      | Файл со списком feature-веток              |
| `mode`               | ❌           | `cherry-pick`          | Режим: `cherry-pick` или `merge`           |

## 🧪 Примеры использования

### Cherry-pick (по умолчанию):
```bash
./merge_features_to_release.sh release/1.2 develop features.txt
```

### Merge-режим:
```bash
./merge_features_to_release.sh release/1.2 develop features.txt merge
```

## 📦 Логирование

Все действия пишутся в `merge_release.log`. Пример:
```
[INFO] 2025-05-15 17:41:32 ▶️ Обработка ветки: feature/cache
```

## 📄 Что делает скрипт

1. Создаёт релизную ветку от `master`, если её нет
2. Для каждой фичи:
   - Находит merge-base
   - Применяет изменения через `cherry-pick` **или** `merge`
   - Откатывает при конфликте
3. Пушит результат в `origin`

## 🧰 Зависимости

- `bash`, `git`, `curl`, `jq`

## 🔐 Переменные окружения (для GitLab API)

| Переменная         | Описание                            |
|--------------------|-------------------------------------|
| `GITLAB_TOKEN`     | GitLab personal access token (PAT)  |
| `GITLAB_PROJECT_ID`| ID проекта                          |
| `LABEL_FILTER`     | Label для отбора MR                 |
| `MILESTONE_FILTER` | (опционально) Milestone             |

## 💡 Советы

- Используй защищённого CI-пользователя с правами на push в `release/*`
- Лейблируй Merge Request'ы метками `release-*` для точного отбора
- Скрипт можно безопасно запускать повторно — он откатывает ошибки

## 🛠️ ToDo / Возможные улучшения

- [ ] `--dry-run` режим
- [ ] Slack / Telegram уведомления
- [ ] Отчёт по каждой ветке в формате JSON/таблицы
- [ ] Docker-обёртка для запуска в CI

## 📝 Лицензия

MIT License
