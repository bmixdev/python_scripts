#!/bin/bash

set -euo pipefail

RELEASE_BRANCH="$1"
DEVELOP_BRANCH="${2:-develop}"
FEATURE_BRANCHES_FILE="$3"
MODE="${4:-cherry-pick}"

GITLAB_API_URL="${GITLAB_API_URL:-https://gitlab.com/api/v4}"
GITLAB_PROJECT_ID="${GITLAB_PROJECT_ID:-}"
GITLAB_TOKEN="${GITLAB_TOKEN:-}"
LABEL_FILTER="${LABEL_FILTER:-}"
MILESTONE_FILTER="${MILESTONE_FILTER:-}"

LOG_FILE="merge_release.log"
> "$LOG_FILE"

timestamped_log() {
  local level="$1"
  local message="$2"
  local color="$3"
  local now
  now=$(date '+%Y-%m-%d %H:%M:%S')
  local formatted="[${level}] $now $message"
  if [[ -n "$color" ]]; then
    echo -e "${color}${formatted}[0m" | tee -a "$LOG_FILE"
  else
    echo "$formatted" | tee -a "$LOG_FILE"
  fi
}

log_info()  { timestamped_log "INFO"  "$1" "[1;34m"; }
log_warn()  { timestamped_log "WARN"  "$1" "[1;33m"; }
log_error() { timestamped_log "ERROR" "$1" "[1;31m"; }

urlencode() {
  local str="$1"
  jq -nr --arg v "$str" '$v|@uri'
}

load_features_from_gitlab() {
  log_info "Загружаем список feature-веток из GitLab по label=$LABEL_FILTER или milestone=$MILESTONE_FILTER"
  local api_url="$GITLAB_API_URL/projects/$GITLAB_PROJECT_ID/merge_requests?state=merged&per_page=100"
  [[ -n "$LABEL_FILTER" ]] && api_url+="&labels=$(urlencode "$LABEL_FILTER")"
  [[ -n "$MILESTONE_FILTER" ]] && api_url+="&milestone=$(urlencode "$MILESTONE_FILTER")"

  curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "$api_url" |
    jq -r '.[] | .source_branch' > "$FEATURE_BRANCHES_FILE"

  log_info "Загружено $(wc -l < "$FEATURE_BRANCHES_FILE") веток из GitLab"
}

# Создание релизной ветки от master если нет
git fetch origin
if ! git rev-parse --verify origin/"$RELEASE_BRANCH" &>/dev/null; then
  log_info "🆕 Релизная ветка $RELEASE_BRANCH ещё не существует. Создаю от master."
  git checkout -b "$RELEASE_BRANCH" origin/master
  git push origin "$RELEASE_BRANCH"
else
  git checkout "$RELEASE_BRANCH"
  git pull origin "$RELEASE_BRANCH"
fi

# Загрузка списка веток
if [[ ! -f "$FEATURE_BRANCHES_FILE" && -n "$LABEL_FILTER" ]]; then
  load_features_from_gitlab
elif [[ ! -f "$FEATURE_BRANCHES_FILE" ]]; then
  log_error "Файл с ветками не найден: $FEATURE_BRANCHES_FILE"
  exit 1
fi

while read -r FEATURE_BRANCH; do
  [[ -z "$FEATURE_BRANCH" ]] && continue
  log_info "▶️ Обработка ветки: $FEATURE_BRANCH"
  git fetch origin "$FEATURE_BRANCH"

  BASE_COMMIT=$(git merge-base origin/"$FEATURE_BRANCH" origin/"$DEVELOP_BRANCH")
  log_info "🧬 merge-base с $DEVELOP_BRANCH: $BASE_COMMIT"
  log_info "📄 Коммиты между base и $FEATURE_BRANCH:"
  git log --oneline "$BASE_COMMIT"..origin/"$FEATURE_BRANCH" | tee -a "$LOG_FILE"

  if [[ "$MODE" == "merge" ]]; then
    TEMP_BRANCH="temp-merge-${FEATURE_BRANCH//\//-}"
    git checkout -B "$TEMP_BRANCH" "$BASE_COMMIT"

    if ! git merge origin/"$FEATURE_BRANCH" --strategy=recursive -X theirs --no-edit; then
      log_warn "⚠️ Конфликт при merge feature → temp ($FEATURE_BRANCH), откатываю"
      git reset --hard "$BASE_COMMIT"
      git checkout "$RELEASE_BRANCH"
      continue
    fi

    git checkout "$RELEASE_BRANCH"
    RELEASE_BEFORE=$(git rev-parse HEAD)

    if ! git merge "$TEMP_BRANCH" --strategy=recursive -X theirs --no-edit; then
      log_warn "⚠️ Конфликт при merge temp → release ($TEMP_BRANCH), откатываю"
      git reset --hard "$RELEASE_BEFORE"
      continue
    fi

    git branch -D "$TEMP_BRANCH"

  elif [[ "$MODE" == "cherry-pick" ]]; then
    log_info "🍒 cherry-pick коммитов между $BASE_COMMIT и $FEATURE_BRANCH"
    git log --reverse --format="%H" "$BASE_COMMIT"..origin/"$FEATURE_BRANCH" | while read commit; do
      if ! git cherry-pick "$commit" -X theirs --no-edit; then
        log_warn "⚠️ Конфликт при cherry-pick $commit, откатываю"
        git cherry-pick --abort
        continue 2
      fi
    done
  else
    log_error "❌ Неизвестный режим: $MODE. Используй merge или cherry-pick"
    exit 1
  fi

done < "$FEATURE_BRANCHES_FILE"

git push origin "$RELEASE_BRANCH"
log_info "✅ Все допустимые ветки вмержены в $RELEASE_BRANCH"
log_info "📘 Лог файл: $LOG_FILE"
